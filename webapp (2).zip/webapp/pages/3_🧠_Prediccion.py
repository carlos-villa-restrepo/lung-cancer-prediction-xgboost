import streamlit as st
import joblib
import pandas as pd
from utils import set_design

st.set_page_config(page_title="Predicción", layout="wide")
set_design("prediction")


st.set_page_config(page_title="Predicción Individual", layout="wide")
set_design()  # Fondo automático

st.title("🧠 Predicción Individual")

meses = st.selectbox("Horizonte temporal", [12, 24, 36, 48, 60])
try:
    modelo = joblib.load(f"model/pipeline_{meses}m.pkl")
except:
    st.error("Error cargando modelo.");
    st.stop()

# --- INPUTS (Resumido para ahorrar espacio, usa tu estructura de columnas) ---
col1, col2 = st.columns(2)
with col1:
    age_group = st.selectbox("Grupo edad", [1, 2, 3, 4, 5, 6])
    tumor_cat = st.selectbox("Cat. Tumor", [1, 2, 3, 4])
    grade = st.selectbox("Grado", [1, 2, 3, 4])
    income = st.selectbox("Ingreso", [1, 2, 3, 4])
    tumors = st.number_input("Tumores", 1, 10)
    primary_site = st.selectbox("Sitio", ["C34.0-Main bronchus", "C34.1-Upper lobe, lung", "C34.2-Middle lobe, lung",
                                          "C34.3-Lower lobe, lung"])

with col2:
    stage = st.selectbox("Estadio", [0, 1, 2, 3, 4])
    surgery = st.selectbox("Cirugía", ["S", "N", "R"])
    chemo = st.selectbox("Quimio", ["Q", "nQ"])
    rad = st.selectbox("Radiación", ["SR", "RR", "UN"])
    histology = st.selectbox("Histología",
                             ["Adenocarcinoma", "Squamous cell carcinoma", "Large cell carcinoma", "Other"])
    tratamiento = f"{surgery} + {chemo} + {rad}"

if st.button("Calcular Predicción"):
    data = pd.DataFrame([{
        'age_group': age_group, 'tumor_category': tumor_cat,
        'grade_clinical': grade, 'income_level': income,
        'Total number of in situ/malignant tumors for patient': tumors,
        'tratamiento': tratamiento, 'Primary Site': primary_site,
        'Stage_Final': stage, 'histology_type_named': histology
    }])

    probs = modelo.predict_proba(data)[0]

    # Resultados
    st.metric("Probabilidad Supervivencia", f"{probs[0]:.2%}")

    # --- ARREGLO DEL GRÁFICO DE IMPORTANCIA ---
    st.subheader("Importancia de Variables")
    try:
        # Obtenemos las importancias numéricas
        importancias = modelo.named_steps["classifier"].feature_importances_

        # SOLUCIÓN: Generamos nombres genéricos si no coinciden las longitudes
        # Esto evita el error "arrays must be same length"
        nombres_cols = [f"Variable_{i}" for i in range(len(importancias))]

        # Intentamos obtener nombres reales si es posible (Opcional avanzado)
        if hasattr(modelo.named_steps.get('preprocessor'), 'get_feature_names_out'):
            try:
                nombres_cols = modelo.named_steps['preprocessor'].get_feature_names_out()
            except:
                pass

        # Creamos el DF solo con las longitudes que coinciden
        df_imp = pd.DataFrame({
            'Variable': nombres_cols[:len(importancias)],
            'Importancia': importancias
        }).sort_values('Importancia', ascending=False).head(10)

        st.bar_chart(df_imp.set_index('Variable'))

    except Exception as e:
        st.warning(f"No se pudo generar el gráfico de importancia: {e}")