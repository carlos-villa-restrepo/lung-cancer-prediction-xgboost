import streamlit as st
from utils import set_design

st.set_page_config(page_title="Título", layout="wide")
set_design("conclusiones")

# CSS Personalizado para mejorar el aspecto
st.markdown("""
    <style>
    .main {
        background-color: #f5f7f9;
    }
    .stButton>button {
        width: 100%;
        border-radius: 5px;
        height: 3em;
        background-color: #007bff;
        color: white;
    }
    .stMetric {
        background-color: #ffffff;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    </style>
    """, unsafe_allow_html=True)



st.markdown("""
### Hallazgos

- Las características tumorales son determinantes clave
- El tratamiento modifica la probabilidad estimada
- El enfoque multihorizonte permite análisis clínico más realista

### Limitaciones

- Datos retrospectivos
- Variables clínicas limitadas
- No sustituye evaluación médica

### Trabajo futuro

- Validación externa
- Más variables clínicas
- Integración clínica real
""")
