import streamlit as st
from utils import set_design

st.set_page_config(page_title="OncoPredict - Equipo", layout="wide")
set_design("equipo")

st.title("Equipo de Desarrollo")
# CSS Personalizado para mejorar el aspecto
st.markdown("""
    <style>
    .main {
        background-color: #f5f7f9;
    }
    .stButton>button {
        width: 100%;
        border-radius: 5px;
        height: 3em;
        background-color: #007bff;
        color: white;
    }
    .stMetric {
        background-color: #ffffff;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    </style>
    """, unsafe_allow_html=True)

st.title("Equipo de Desarrollo")

def perfil(nombre, rol, linkedin, github):
    st.subheader(nombre)
    st.write(rol)
    st.markdown(f"🔗 [LinkedIn]({linkedin})")
    st.markdown(f"💻 [GitHub]({github})")
    st.divider()

perfil(
    "Betania Median",
    "Data Scientist",
    "https://www.linkedin.com/in/betania-medina-b2b733269/",
    "https://github.com/Betaniammc"
)

perfil(
    "Carlos Restrepo",
    "Data Scientist",
    "https://www.linkedin.com/in/carlos-restrepo-a7b188390/",
    "https://github.com/carlos-villa-restrepo"
)

perfil(
    "Elius Trujillo",
    "Data Scientist",
    "https://www.linkedin.com/in/elius-trujillo",
    "https://github.com/elius123ef"
)
