import streamlit as st
from utils import set_design

st.set_page_config(page_title="Metodología", layout="wide")
set_design("metodologia")

st.title("Metodología del Proyecto")

# CSS Personalizado para mejorar el aspecto
st.markdown("""
    <style>
    .main {
        background-color: #f5f7f9;
    }
    .stButton>button {
        width: 100%;
        border-radius: 5px;
        height: 3em;
        background-color: #007bff;
        color: white;
    }
    .stMetric {
        background-color: #ffffff;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    </style>
    """, unsafe_allow_html=True)

st.title("Metodología del Proyecto")

tab1, tab2, tab3, tab4 = st.tabs([
    "Objetivo",
    "Datos",
    "Preparación",
    "Modelado"
])

with tab1:
    st.header("Objetivo")
    st.write("""
    Estimar la probabilidad de muerte por cáncer de pulmón antes de distintos horizontes temporales
    utilizando variables clínicas disponibles al diagnóstico.
    """)

with tab2:
    st.header("Fuente de Datos")
    st.write("""
    Datos del programa SEER (Surveillance, Epidemiology, and End Results).

    Incluyen:
    - Características demográficas
    - Información tumoral
    - Tratamientos
    - Supervivencia
    """)

with tab3:
    st.header("Preparación de Datos")
    st.write("""
    - Limpieza de valores inconsistentes
    - Codificación de variables categóricas
    - Creación de targets por horizonte temporal
    - Filtrado dinámico de pacientes por hito
    """)

with tab4:
    st.header("Modelo")
    st.write("""
    Se entrenaron modelos independientes por horizonte temporal
    usando XGBoost dentro de un Pipeline de Scikit-learn.

    Cada modelo incluye:
    - Escalado de variables numéricas
    - One-hot encoding
    - Clasificador XGBoost
    """)
