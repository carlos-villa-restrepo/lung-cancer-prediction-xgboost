import streamlit as st
import joblib
import pandas as pd
from utils import set_design  # <--- Importamos nuestro nuevo estilo

st.set_page_config(page_title="Escenarios", layout="wide")
set_design("scenarios") # Imagen de pulmones/rayos X

# 1. Configuración y Estilo
st.set_page_config(page_title="Simulación de Estrategias", layout="wide")
set_design()  # <--- Aplicamos el fondo automáticamente

st.title("🔬 Simulación de Tratamientos")

# 2. Carga del Modelo
meses = st.selectbox("Horizonte temporal (Meses)", [12, 24, 36, 48, 60])
try:
    modelo = joblib.load(f"model/pipeline_{meses}m.pkl")
except:
    st.error("No se encuentra el modelo.")
    st.stop()

# 3. Datos del Paciente
col1, col2, col3 = st.columns(3)

with col1:
    st.subheader("Datos Básicos")
    age_group = st.selectbox("Grupo edad", [1, 2, 3, 4, 5, 6])
    income = st.selectbox("Nivel ingreso", [1, 2, 3, 4])

with col2:
    st.subheader("Perfil Tumoral")
    tumor_category = st.selectbox("Categoría tumor", [1, 2, 3, 4])
    grade = st.selectbox("Grado clínico", [1, 2, 3, 4])
    tumors = st.number_input("Número tumores", 0, 10, value=1)

with col3:
    st.subheader("Ubicación y Tipo")
    primary_site = st.selectbox("Sitio primario (Ubicación)", [
        "C34.0-Main bronchus", "C34.1-Upper lobe, lung",
        "C34.2-Middle lobe, lung", "C34.3-Lower lobe, lung"
    ])

    # Insertar imagen de referencia anatómica
    st.image(
        "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Lung_lobes_diagram.svg/800px-Lung_lobes_diagram.svg.png",
        caption="Referencia anatómica para selección de sitio primario",
        use_container_width=True)
    st.caption("Diagrama de referencia para la codificación ICD-O-3 (C34.0 - C34.3)")

    stage = st.selectbox("Estadio (Stage)", [0, 1, 2, 3, 4])
    histology = st.selectbox("Histología",
                             ["Adenocarcinoma", "Squamous cell carcinoma", "Large cell carcinoma", "Other"])


# 4. Simulación
tratamientos = ["S + Q + SR", "S + Q + UN", "N + Q + SR", "N + nQ + UN", "R + Q + SR"]

if st.button("🔄 Ejecutar Simulación"):
    resultados_lista = []

    for t in tratamientos:
        # Creamos el DF con TODAS las columnas necesarias
        row = {
            'age_group': age_group, 'tumor_category': tumor_category,
            'grade_clinical': grade, 'income_level': income,
            'Total number of in situ/malignant tumors for patient': tumors,
            'tratamiento': t, 'Primary Site': primary_site,
            'Stage_Final': stage, 'histology_type_named': histology  # <--- Corrección del error
        }

        prob = modelo.predict_proba(pd.DataFrame([row]))[0][1]  # Probabilidad de muerte
        resultados_lista.append({
            "Estrategia": t,
            "Prob. Supervivencia": (1 - prob) * 100  # En porcentaje para el gráfico
        })

    # Crear DF de resultados
    df_res = pd.DataFrame(resultados_lista)

    # --- ARREGLO DEL GRÁFICO BLANCO ---
    # Para que st.bar_chart funcione perfecto, definimos el índice
    df_chart = df_res.set_index("Estrategia")

    st.subheader(f"Comparativa Visual ({meses} meses)")
    # Graficamos explícitamente la columna de supervivencia
    st.bar_chart(df_chart["Prob. Supervivencia"])

    # Tabla de datos (Tu preferencia [2026-01-28])
    st.write("### Tabla de Detalles")
    st.dataframe(df_res.style.format({"Prob. Supervivencia": "{:.2f}%"}))