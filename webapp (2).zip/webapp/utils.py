import streamlit as st

def set_design(section="general"):
    images = {
        "home": "https://images.unsplash.com/photo-1532187875605-1ef6c8169143?q=80&w=2000",
        "eda": "https://images.unsplash.com/photo-1551288049-bbda38a5f9ce?q=80&w=2000",
        "metodologia": "https://images.unsplash.com/photo-1454165833762-0204b2816721?q=80&w=2000",
        "rendimiento": "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2000",
        "conclusiones": "https://images.unsplash.com/photo-1507413245164-6160d8298b31?q=80&w=2000",
        "equipo": "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2000",
        "prediction": "https://images.unsplash.com/photo-1576086213369-97a306d36557?q=80&w=2000",
        "scenarios": "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=2000",
        "general": "https://images.unsplash.com/photo-1504813184591-01572f98c85f?q=80&w=2000"
    }

    bg_image = images.get(section, images["general"])

    st.markdown(f"""
            <style>
            /* 1. Fondo de la aplicación */
            .stApp {{
                background: url("{bg_image}");
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
            }}

            /* 2. ELIMINAR ESPACIOS EN BLANCO (Reset de Padding) */
            .block-container {{
                padding-top: 1rem !important;    /* Reduce el espacio arriba */
                padding-bottom: 0rem !important; /* Reduce el espacio abajo */
                max-width: 95% !important;
            }}

            .stAppHeader {{
                background-color: transparent !important;
                display: none; /* Opcional: oculta la barra superior de Streamlit */
            }}

            /* 3. Hacer transparentes las capas base */
            .stAppViewMain, .stMain, .stMainBlockContainer {{
                background-color: transparent !important;
            }}

            /* 4. Bloques de contenido (Efecto cristal) */
            .stMarkdown, .stDataFrame, [data-testid="stVerticalBlock"] > div {{
                background-color: rgba(255, 255, 255, 0.90) !important;
                border-radius: 12px !important;
                padding: 15px !important;
                margin-top: 0px !important;
                margin-bottom: 10px !important;
                box-shadow: 0 4px 10px rgba(0,0,0,0.15) !important;
            }}

            /* 5. Asegurar que los DataFrames no tengan bordes raros */
            .stDataFrame {{
                border: none !important;
            }}
            </style>
            """, unsafe_allow_html=True)