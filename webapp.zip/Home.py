import streamlit as st
from utils import set_design

# CONFIGURACIÓN ÚNICA - Debe ser lo primero
st.set_page_config(page_title="Predicción Oncológica", layout="wide")

# APLICAR DISEÑO
set_design("home")

st.title("🧬 Predicción Oncológica: Soporte Clínico")

st.markdown("""
### Resumen Ejecutivo
Bienvenido al panel de control de **Predicción Oncológica**. Esta plataforma utiliza modelos de Machine Learning 
para asistir en la toma de decisiones clínicas sobre cáncer de pulmón.
""")

st.divider()

# Fila 1
c1, c2, c3 = st.columns(3)
with c1:
    st.info("### 📊 Análisis")
    if st.button("Ir a Análisis", key="h_1"):
        st.switch_page("pages/1_📊_Analisis_Exploratorio.py")
with c2:
    st.success("### 📊 EDA")
    if st.button("Ir a EDA", key="h_2"):
        st.switch_page("pages/2_📊_EDA.py")
with c3:
    st.success("### 🧠 Predicción")
    if st.button("Ir a Predicción", key="h_3"):
        st.switch_page("pages/3_🧠_Prediccion.py")

# Fila 2
c4, c5, c6 = st.columns(3)
with c4:
    st.warning("### 💲 Escenarios")
    if st.button("Ir a Escenarios", key="h_4"):
        st.switch_page("pages/4_💲_Escenarios_Tratamiento.py")
with c5:
    st.info("### 📈 Rendimiento")
    if st.button("Ir a Rendimiento", key="h_5"):
        st.switch_page("pages/5_📈_Rendimiento_Modelos.py")
with c6:
    st.info("### 📌 Conclusiones")
    if st.button("Ir a Conclusiones", key="h_6"):
        st.switch_page("pages/6_📌_Conclusiones.py")